﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Demo.Models;

namespace Demo.Data
{
    public class DemoContext : DbContext
    {
        public DemoContext (DbContextOptions<DemoContext> options)
            : base(options)
        {
        }

        public DbSet<Demo.Models.Plans> Plans { get; set; } = default!;

        public DbSet<Demo.Models.Users> Users { get; set; }

        public DbSet<Demo.Models.Devices> Devices { get; set; }
    }
}
