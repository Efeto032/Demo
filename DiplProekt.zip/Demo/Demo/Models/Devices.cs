﻿using System.ComponentModel.DataAnnotations;

namespace Demo.Models
{
    public class Devices
    {
        [Key]

        public int ID { get; set; }

        [Required]

        public string? deviceName { get; set; }

        public double devicePrice { get; set; }

        public string? deviceDetails { get; set; }
    }
}
