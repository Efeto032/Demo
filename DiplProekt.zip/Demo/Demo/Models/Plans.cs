﻿using System.ComponentModel.DataAnnotations;

namespace Demo.Models
{
    public class Plans
    {
        [Key]

        public int ID { get; set; }

        [Required]

        public string? Name { get; set; }

        public double Price { get; set; }

        public string? Details { get; set; }
    }
}
